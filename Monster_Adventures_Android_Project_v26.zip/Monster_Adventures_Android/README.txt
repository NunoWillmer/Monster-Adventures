MONSTER ADVENTURES — Android project source

This package is an Android Studio project wrapping the game's HTML in a native Android WebView. The HTML game is bundled locally so it can run offline.

IMPORTANT: This ZIP is project source, not an APK. The current workspace has no Android SDK/Gradle installation and cannot reach Google's build repositories, so an APK could not be compiled here.

BUILD LOCALLY (computer with Android Studio):
1. Extract this ZIP.
2. Open the Monster_Adventures_Android folder in Android Studio.
3. Let Gradle sync and install the requested Android SDK (API 35) if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be in app/build/outputs/apk/debug/app-debug.apk.

BUILD IN THE CLOUD (can be managed from a browser, but requires a GitHub account):
1. Create a new GitHub repository.
2. Upload the contents of this project folder to the repository root (not the enclosing folder).
3. Open the Actions tab and run “Build Monster Adventures APK” (or push to main/master).
4. Open the completed workflow run and download the “Monster-Adventures-APK” artifact ZIP. Extract app-debug.apk and transfer it to the Android phone.
5. On Android, open the APK and allow installation from that source if prompted. Only install APKs from sources you trust.

The workflow creates a debug APK for testing, not a Play Store release. No APK has been built or device-tested in this workspace.
